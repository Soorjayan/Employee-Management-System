# Employee Management System - Backend

Backend API for SyntechHub Project 3: Employee Management System.

## Tech Stack

- Node.js
- Express.js
- MongoDB
- Mongoose
- CORS
- dotenv
- Nodemon

## Project Structure

```text
backend/
├── config/
│   └── db.js
├── controllers/
│   └── employeeController.js
├── middleware/
│   └── errorMiddleware.js
├── models/
│   └── Employee.js
├── routes/
│   └── employeeRoutes.js
├── .env.example
├── .gitignore
├── package.json
├── README.md
└── server.js
```

## Setup

1. Open the backend folder in VS Code.
2. Install dependencies:

```bash
npm install
```

3. Create a `.env` file by copying `.env.example`.

For local MongoDB:

```env
PORT=5000
MONGO_URI=mongodb://127.0.0.1:27017/employee_management_db
```

For MongoDB Atlas, replace `MONGO_URI` with your Atlas connection string.

4. Start the server:

```bash
npm run dev
```

## API Endpoints

### Health Check

```http
GET /
```

### Employees

```http
POST   /api/employees
GET    /api/employees
GET    /api/employees/:id
PUT    /api/employees/:id
DELETE /api/employees/:id
```

### Query Parameters

The employee list supports:

```text
search
department
status
sort
page
limit
```

Example:

```http
GET /api/employees?search=john&status=Active&page=1&limit=10
```

## Example Employee JSON

```json
{
  "name": "John Doe",
  "email": "john@example.com",
  "phone": "0771234567",
  "role": "Software Engineer",
  "department": "Engineering",
  "salary": 150000,
  "joiningDate": "2026-09-27",
  "status": "Active"
}
```

## Next Development Step

After confirming that this backend connects successfully to MongoDB, build and connect the React frontend.
