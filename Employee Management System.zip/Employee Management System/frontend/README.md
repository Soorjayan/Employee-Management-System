# Employee Management System — Admin Frontend

Updated according to the latest UI requirements.

## Main features

- Admin login and sign-up
- Dark/light mode
- Compact centered login card
- EMS Employee Manager branding inside login card
- Dashboard greeting and admin profile button
- 2 × 2 large dashboard statistic cards
- Dashboard cards navigate to the related views
- All Employees without an Actions column
- Click an employee row to open Employee Details
- Employee Details page with Edit Employee and Delete Employee
- Manage Employees with Add Employee and Edit Employee cards
- Edit Employee includes search, filters, sorting, edit and delete
- Employee profile image upload
- Department cards
- Department employee rows open Employee Details
- Admin Settings/Profile
- Admin profile image
- Logout

## Backend

The frontend uses the existing API:

http://localhost:5000/api

## Run

```bash
npm install
npm run dev
```

## Demo login

If no admin account has been registered yet:

Username: `admin`
Password: `admin123`

Admin authentication in this version is local browser storage. It is suitable for the frontend demonstration; production authentication should use a backend user model, hashed passwords and JWT/session authentication.
