import React, { useEffect, useMemo, useState } from "react";
import {
  UserRound, Users, LayoutDashboard, Building2, Edit3, LogOut, Settings,
  Moon, Sun, ChevronRight, Search, Filter, Trash2, Mail, Phone,
  BriefcaseBusiness, CheckCircle2, UserRoundX, Plus, X, Camera,
  ShieldCheck, LockKeyhole, Eye, EyeOff, Menu, Save, ArrowLeft,
  KeyRound, UserPlus, CalendarDays, MapPin, BadgeDollarSign
} from "lucide-react";
import { employeeApi } from "./api";

const initialEmployee = {
  name: "", email: "", phone: "", role: "", department: "",
  salary: "", joiningDate: new Date().toISOString().slice(0, 10),
  status: "Active"
};

const departments = [
  "Engineering", "Design", "Management", "Human Resources",
  "Finance", "Marketing", "Sales", "Operations"
];

const roles = [
  "Software Engineer", "Full Stack Developer", "Frontend Developer",
  "Backend Developer", "UI/UX Designer", "Project Manager",
  "HR Executive", "Data Analyst", "QA Engineer"
];

const defaultAdmin = {
  name: "Administrator",
  username: "admin",
  email: "admin@ems.local",
  phone: "",
  password: "admin123",
  photo: ""
};

function getAdminAccounts() {
  try { return JSON.parse(localStorage.getItem("ems_admin_accounts") || "[]"); }
  catch { return []; }
}

function saveAdminAccounts(accounts) {
  localStorage.setItem("ems_admin_accounts", JSON.stringify(accounts));
}

function getCurrentAdmin() {
  try { return JSON.parse(localStorage.getItem("ems_current_admin") || "null"); }
  catch { return null; }
}

function setCurrentAdmin(admin) {
  if (admin) localStorage.setItem("ems_current_admin", JSON.stringify(admin));
  else localStorage.removeItem("ems_current_admin");
}

function getImageMap() {
  try { return JSON.parse(localStorage.getItem("ems_employee_images") || "{}"); }
  catch { return {}; }
}

function saveImageMap(map) {
  localStorage.setItem("ems_employee_images", JSON.stringify(map));
}

function errorMessage(error) {
  return error?.response?.data?.message ||
    error?.response?.data?.error ||
    error?.message || "Something went wrong. Please try again.";
}

function currency(value) {
  return new Intl.NumberFormat("en-LK", {
    style: "currency", currency: "LKR", maximumFractionDigits: 0
  }).format(Number(value || 0));
}

function dateText(value) {
  if (!value) return "-";
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return value;
  return d.toLocaleDateString("en-GB", {
    day: "2-digit", month: "short", year: "numeric"
  });
}

function initials(name = "") {
  return name.split(" ").filter(Boolean)
    .map(x => x[0]).slice(0, 2).join("").toUpperCase() || "AD";
}

export default function App() {
  const [admin, setAdmin] = useState(getCurrentAdmin());
  const [dark, setDark] = useState(() =>
    localStorage.getItem("ems_dark_mode") === "true"
  );

  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
    localStorage.setItem("ems_dark_mode", String(dark));
  }, [dark]);

  if (!admin) {
    return <AuthPage onLogin={(user) => {
      setCurrentAdmin(user);
      setAdmin(user);
    }} dark={dark} setDark={setDark} />;
  }

  return (
    <Portal
      admin={admin}
      setAdmin={setAdmin}
      dark={dark}
      setDark={setDark}
    />
  );
}

/* =========================
   LOGIN / SIGN UP
========================= */

function AuthPage({ onLogin, dark, setDark }) {
  const [mode, setMode] = useState("login");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");

  const [form, setForm] = useState({
    name: "", username: "", email: "", phone: "",
    password: "", confirmPassword: ""
  });

  function update(field, value) {
    setForm(f => ({ ...f, [field]: value }));
    setError("");
  }

  function submit(e) {
    e.preventDefault();
    setError("");

    if (mode === "login") {
      const username = form.username.trim().toLowerCase();
      const password = form.password;

      const accounts = getAdminAccounts();
      const candidates = accounts.length ? accounts : [defaultAdmin];

      const user = candidates.find(
        a => a.username.toLowerCase() === username && a.password === password
      );

      if (!user) {
        setError("Invalid username or password.");
        return;
      }

      onLogin(user);
      return;
    }

    if (form.name.trim().length < 2) {
      return setError("Enter the admin's full name.");
    }

    if (form.username.trim().length < 3) {
      return setError("Username must contain at least 3 characters.");
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      return setError("Enter a valid email address.");
    }

    if (form.password.length < 6) {
      return setError("Password must contain at least 6 characters.");
    }

    if (form.password !== form.confirmPassword) {
      return setError("Passwords do not match.");
    }

    const accounts = getAdminAccounts();

    if (accounts.some(
      a => a.username.toLowerCase() === form.username.trim().toLowerCase()
    )) {
      return setError("That username is already registered.");
    }

    const user = {
      name: form.name.trim(),
      username: form.username.trim(),
      email: form.email.trim(),
      phone: form.phone.trim(),
      password: form.password,
      photo: ""
    };

    saveAdminAccounts([...accounts, user]);
    onLogin(user);
  }

  return (
    <div className="auth-page">
      <div className="auth-center">
        <div className="auth-card">
          <button
            className="auth-theme-button"
            onClick={() => setDark(!dark)}
            title="Toggle dark mode"
          >
            {dark ? <Sun /> : <Moon />}
          </button>

          <div className="auth-brand-center">
            <div className="auth-brand-icon"><Users /></div>
            <div>
              <b>EMS</b>
              <span>Employee Manager</span>
            </div>
          </div>

          <div className="auth-heading">
            <small>ADMINISTRATION PORTAL</small>
            <h1>{mode === "login" ? "Welcome back" : "Create admin account"}</h1>
            <p>
              {mode === "login"
                ? "Sign in to manage your employee management system."
                : "Register an administrator account to access EMS."}
            </p>
          </div>

          {error && <Alert type="error" text={error} close={() => setError("")} />}

          <form className="auth-form" onSubmit={submit}>
            {mode === "signup" && (
              <>
                <AuthField label="Full Name">
                  <input
                    value={form.name}
                    onChange={e => update("name", e.target.value)}
                    placeholder="Admin Name"
                  />
                </AuthField>

                <AuthField label="Email">
                  <input
                    type="email"
                    value={form.email}
                    onChange={e => update("email", e.target.value)}
                    placeholder="admin@example.com"
                  />
                </AuthField>

                <AuthField label="Phone">
                  <input
                    value={form.phone}
                    onChange={e => update("phone", e.target.value)}
                    placeholder="0771234567"
                  />
                </AuthField>
              </>
            )}

            <AuthField label="Username">
              <div className="input-icon">
                <UserRound />
                <input
                  value={form.username}
                  onChange={e => update("username", e.target.value)}
                  placeholder="admin"
                  autoComplete="username"
                />
              </div>
            </AuthField>

            <AuthField label="Password">
              <div className="input-icon">
                <LockKeyhole />
                <input
                  type={showPassword ? "text" : "password"}
                  value={form.password}
                  onChange={e => update("password", e.target.value)}
                  placeholder={mode === "login" ? "Enter password" : "Minimum 6 characters"}
                  autoComplete={mode === "login" ? "current-password" : "new-password"}
                />
                <button
                  type="button"
                  className="password-toggle"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOff /> : <Eye />}
                </button>
              </div>
            </AuthField>

            {mode === "signup" && (
              <AuthField label="Confirm Password">
                <div className="input-icon">
                  <KeyRound />
                  <input
                    type={showPassword ? "text" : "password"}
                    value={form.confirmPassword}
                    onChange={e => update("confirmPassword", e.target.value)}
                    placeholder="Repeat password"
                  />
                </div>
              </AuthField>
            )}

            <button className="auth-submit" type="submit">
              {mode === "login"
                ? <><LockKeyhole /> Login</>
                : <><UserPlus /> Create Account</>}
            </button>
          </form>

          <div className="auth-switch">
            {mode === "login"
              ? <>Don't have an admin account? <button onClick={() => {
                  setMode("signup");
                  setError("");
                }}>Sign up</button></>
              : <>Already have an account? <button onClick={() => {
                  setMode("login");
                  setError("");
                }}>Login</button></>}
          </div>
        </div>
      </div>

      <footer className="auth-footer">
        © 2026 Employee Management System. All rights reserved.
      </footer>
    </div>
  );
}

function AuthField({ label, children }) {
  return (
    <label className="auth-field">
      <span>{label}</span>
      {children}
    </label>
  );
}

/* =========================
   PORTAL / NAVIGATION
========================= */

function Portal({ admin, setAdmin, dark, setDark }) {
  const [view, setView] = useState("dashboard");
  const [navigationParams, setNavigationParams] = useState({});
  const [mobileOpen, setMobileOpen] = useState(false);
  const [profileMessage, setProfileMessage] = useState("");

  function navigate(next, params = {}) {
    setView(next);
    setNavigationParams(params || {});
    setMobileOpen(false);
  }

  function logout() {
    setCurrentAdmin(null);
    setAdmin(null);
  }

  function updateAdmin(updated) {
    const accounts = getAdminAccounts();
    const index = accounts.findIndex(a => a.username === admin.username);

    if (index >= 0) {
      const copy = [...accounts];
      copy[index] = updated;
      saveAdminAccounts(copy);
    } else {
      saveAdminAccounts([updated]);
    }

    setCurrentAdmin(updated);
    setAdmin(updated);
    setProfileMessage("Profile updated successfully.");

    setTimeout(() => setProfileMessage(""), 2500);
  }

  return (
    <div className="app">
      <aside className={`sidebar ${mobileOpen ? "open" : ""}`}>
        <div className="brand">
          <div className="brand-icon"><Users /></div>
          <div><b>EMS</b><span>Employee Manager</span></div>
          <button
            className="icon-btn close-mobile"
            onClick={() => setMobileOpen(false)}
          >
            <X />
          </button>
        </div>

        <nav className="main-nav">
          <NavItem active={view === "dashboard"} icon={<LayoutDashboard />} label="Dashboard" onClick={() => navigate("dashboard")} />
          <NavItem active={view === "all"} icon={<Users />} label="All Employees" onClick={() => navigate("all")} />
          <NavItem active={view === "manage"} icon={<Edit3 />} label="Manage Employees" onClick={() => navigate("manage")} />
          <NavItem active={view === "departments"} icon={<Building2 />} label="Departments" onClick={() => navigate("departments")} />
        </nav>

        <div className="sidebar-bottom">
          <button
            className={`nav-item ${view === "settings" ? "active" : ""}`}
            onClick={() => navigate("settings")}
          >
            <Settings /> Settings
          </button>

          <button className="nav-item logout-item" onClick={logout}>
            <LogOut /> Logout
          </button>

          <button
            className="side-admin"
            onClick={() => navigate("settings")}
            title="Open admin profile"
          >
            <ProfileAvatar admin={admin} size={40} />
            <div>
              <b>{admin.name}</b>
              <span>@{admin.username}</span>
            </div>
          </button>
        </div>
      </aside>

      {mobileOpen && (
        <button
          className="overlay"
          onClick={() => setMobileOpen(false)}
        />
      )}

      <main className="main">
        <header className="topbar">
          <button
            className="icon-btn mobile-menu"
            onClick={() => setMobileOpen(true)}
          >
            <Menu />
          </button>

          <div className="top-title">
            <small>MANAGEMENT PORTAL</small>
            <h1>
              {view === "dashboard"
                ? `Good day, ${admin.name}`
                : viewTitle(view, navigationParams)}
            </h1>
          </div>

          <div className="header-actions">
            <button
              className="theme-button"
              onClick={() => setDark(!dark)}
              title="Toggle dark mode"
            >
              {dark ? <Sun /> : <Moon />}
            </button>

            <button
              className="profile-button"
              onClick={() => navigate("settings")}
              title="Open admin profile"
            >
              <ProfileAvatar admin={admin} size={40} />
              <span>
                <b>{admin.name}</b>
                <small>Administrator</small>
              </span>
              <ChevronRight />
            </button>
          </div>
        </header>

        <div className="content">
          {profileMessage && (
            <Alert
              type="success"
              text={profileMessage}
              close={() => setProfileMessage("")}
            />
          )}

          {view === "dashboard" && <Dashboard onNavigate={navigate} />}

          {view === "all" && (
            <AllEmployees
              initialStatus={navigationParams.status || ""}
              onNavigate={navigate}
            />
          )}

          {view === "manage" && (
            <ManageEmployees
              onNavigate={navigate}
              initialEmployee={navigationParams.employee || null}
            />
          )}

          {view === "departments" && (
            <Departments onNavigate={navigate} />
          )}

          {view === "details" && (
            <EmployeeDetails
              employee={navigationParams.employee}
              onBack={() => navigate(navigationParams.backView || "all", navigationParams.backParams || {})}
              onEdit={(employee) => navigate("manage", { employee })}
            />
          )}

          {view === "settings" && (
            <AdminProfile admin={admin} onSave={updateAdmin} />
          )}
        </div>
      </main>
    </div>
  );
}

function NavItem({ active, icon, label, onClick }) {
  return (
    <button className={`nav-item ${active ? "active" : ""}`} onClick={onClick}>
      {icon}{label}
    </button>
  );
}

function viewTitle(view, params) {
  if (view === "all") {
    return params.status ? `${params.status} Employees` : "All Employees";
  }
  if (view === "manage") return "Manage Employees";
  if (view === "departments") return "Departments";
  if (view === "details") return "Employee Details";
  if (view === "settings") return "Admin Profile";
  return "Employee Dashboard";
}

function ProfileAvatar({ admin, size = 40 }) {
  return admin?.photo
    ? <img className="profile-avatar" style={{ width: size, height: size }} src={admin.photo} alt={admin.name} />
    : <div className="profile-avatar initials-avatar" style={{ width: size, height: size }}>{initials(admin?.name)}</div>;
}

/* =========================
   DASHBOARD
========================= */

function Dashboard({ onNavigate }) {
  const [stats, setStats] = useState({
    total: 0, active: 0, inactive: 0, departments: 0
  });
  const [error, setError] = useState("");

  useEffect(() => {
    employeeApi.getAll({ page: 1, limit: 1000 })
      .then(res => {
        const all = res.data?.data || [];

        setStats({
          total: res.data?.pagination?.total ?? all.length,
          active: all.filter(e => e.status === "Active").length,
          inactive: all.filter(e => e.status === "Inactive").length,
          departments: new Set(all.map(e => e.department)).size
        });
      })
      .catch(e => setError(errorMessage(e)));
  }, []);

  return (
    <>
      {error && <Alert type="error" text={error} close={() => setError("")} />}

      <section className="dashboard-grid">
        <DashboardCard
          icon={<Users />}
          title="Total Employees"
          value={stats.total}
          note="All registered employees"
          onClick={() => onNavigate("all", { status: "" })}
        />

        <DashboardCard
          icon={<CheckCircle2 />}
          title="Active Employees"
          value={stats.active}
          note="Currently active"
          onClick={() => onNavigate("all", { status: "Active" })}
        />

        <DashboardCard
          icon={<UserRoundX />}
          title="Inactive Employees"
          value={stats.inactive}
          note="Currently inactive"
          onClick={() => onNavigate("all", { status: "Inactive" })}
        />

        <DashboardCard
          icon={<Building2 />}
          title="Departments"
          value={stats.departments}
          note="Departments with employees"
          onClick={() => onNavigate("departments")}
        />
      </section>
    </>
  );
}

function DashboardCard({ icon, title, value, note, onClick }) {
  return (
    <button className="dashboard-card" onClick={onClick}>
      <div className="dashboard-icon">{icon}</div>
      <span className="dashboard-title">{title}</span>
      <strong>{value}</strong>
      <small>{note}</small>
      <span className="card-link">Open <ChevronRight /></span>
    </button>
  );
}

/* =========================
   ALL EMPLOYEES
========================= */

function AllEmployees({ initialStatus = "", onNavigate }) {
  const [employees, setEmployees] = useState([]);
  const [pagination, setPagination] = useState({
    total: 0, page: 1, limit: 8, totalPages: 1
  });
  const [search, setSearch] = useState("");
  const [department, setDepartment] = useState("");
  const [status, setStatus] = useState(initialStatus);
  const [sort, setSort] = useState("-joiningDate");
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const query = useMemo(() => ({
    page,
    limit: pagination.limit,
    ...(search.trim() ? { search: search.trim() } : {}),
    ...(department ? { department } : {}),
    ...(status ? { status } : {}),
    ...(sort ? { sort } : {})
  }), [page, pagination.limit, search, department, status, sort]);

  async function load() {
    setLoading(true);
    setError("");

    try {
      const res = await employeeApi.getAll(query);
      const map = getImageMap();

      setEmployees(
        (res.data?.data || []).map(e => ({
          ...e,
          profileImage: map[e._id] || ""
        }))
      );

      setPagination(p => ({
        ...p,
        ...(res.data?.pagination || {})
      }));
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, [
    query.page, query.limit, query.search,
    query.department, query.status, query.sort
  ]);

  function clear() {
    setSearch("");
    setDepartment("");
    setStatus("");
    setSort("-joiningDate");
    setPage(1);
  }

  return (
    <section className="panel employee-list-panel">
      {error && (
        <div className="inner-alert">
          <Alert type="error" text={error} close={() => setError("")} />
        </div>
      )}

      <div className="panel-head">
        <div>
          <h2>Employee Directory</h2>
          <p>Click an employee to view complete employee details.</p>
        </div>
      </div>

      <EmployeeFilters
        search={search}
        setSearch={v => { setSearch(v); setPage(1); }}
        department={department}
        setDepartment={v => { setDepartment(v); setPage(1); }}
        status={status}
        setStatus={v => { setStatus(v); setPage(1); }}
        sort={sort}
        setSort={v => { setSort(v); setPage(1); }}
        clear={clear}
      />

      <EmployeeTable
        employees={employees}
        loading={loading}
        showActions={false}
        onEmployeeClick={employee => onNavigate("details", {
          employee,
          backView: "all",
          backParams: { status }
        })}
      />

      <Pagination
        pagination={pagination}
        page={page}
        setPage={setPage}
        loading={loading}
      />
    </section>
  );
}

/* =========================
   MANAGE EMPLOYEES
========================= */

function ManageEmployees({ onNavigate, initialEmployee }) {
  const [mode, setMode] = useState(initialEmployee ? "edit" : "choice");
  const [selected, setSelected] = useState(initialEmployee || null);

  useEffect(() => {
    if (initialEmployee) {
      setSelected(initialEmployee);
      setMode("edit");
    }
  }, [initialEmployee]);

  if (mode === "choice") {
    return (
      <section className="manage-choice">
        <div className="manage-intro">
          <div className="section-icon"><Edit3 /></div>
          <div>
            <h2>Manage Employees</h2>
            <p>Choose an action to manage employee records.</p>
          </div>
        </div>

        <div className="manage-choice-grid">
          <button
            className="action-card"
            onClick={() => {
              setSelected(null);
              setMode("add");
            }}
          >
            <div className="action-card-icon add"><Plus /></div>
            <div>
              <b>Add Employee</b>
              <span>Create a new employee record and upload a profile image.</span>
            </div>
            <ChevronRight />
          </button>

          <button
            className="action-card"
            onClick={() => setMode("edit")}
          >
            <div className="action-card-icon edit"><Edit3 /></div>
            <div>
              <b>Edit Employee</b>
              <span>Search employees and open a record to edit or delete it.</span>
            </div>
            <ChevronRight />
          </button>
        </div>
      </section>
    );
  }

  if (mode === "add") {
    return (
      <section className="panel standalone-form">
        <BackButton onClick={() => setMode("choice")} />

        <div className="panel-head">
          <div>
            <h2>Add Employee</h2>
            <p>Create a new employee record.</p>
          </div>
        </div>

        <EmployeeForm
          onSaved={() => setMode("choice")}
        />
      </section>
    );
  }

  return (
    <EditEmployees
      onBack={() => setMode("choice")}
      initialEmployee={selected}
      onNavigate={onNavigate}
    />
  );
}

function EditEmployees({ onBack, initialEmployee, onNavigate }) {
  const [employees, setEmployees] = useState([]);
  const [pagination, setPagination] = useState({
    total: 0, page: 1, limit: 8, totalPages: 1
  });
  const [search, setSearch] = useState("");
  const [department, setDepartment] = useState("");
  const [status, setStatus] = useState("");
  const [sort, setSort] = useState("-joiningDate");
  const [page, setPage] = useState(1);
  const [selected, setSelected] = useState(initialEmployee || null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function load() {
    setLoading(true);
    setError("");

    try {
      const res = await employeeApi.getAll({
        page,
        limit: pagination.limit,
        ...(search.trim() ? { search: search.trim() } : {}),
        ...(department ? { department } : {}),
        ...(status ? { status } : {}),
        sort
      });

      const map = getImageMap();

      setEmployees(
        (res.data?.data || []).map(e => ({
          ...e,
          profileImage: map[e._id] || ""
        }))
      );

      setPagination(p => ({
        ...p,
        ...(res.data?.pagination || {})
      }));
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, [page, pagination.limit, search, department, status, sort]);

  if (selected) {
    return (
      <section className="panel standalone-form">
        <BackButton
          onClick={() => setSelected(null)}
          label="Back to Employee List"
        />

        <div className="panel-head">
          <div>
            <h2>Edit Employee</h2>
            <p>Update employee information and profile image.</p>
          </div>
        </div>

        <EmployeeForm
          employee={selected}
          onSaved={() => {
            setSelected(null);
            load();
          }}
        />
      </section>
    );
  }

  async function remove(employee) {
    if (!employee?._id) {
      setError("Invalid employee ID.");
      return;
    }

    if (!window.confirm(
      `Delete ${employee.name}? This action cannot be undone.`
    )) return;

    try {
      await employeeApi.remove(employee._id);

      const map = getImageMap();
      delete map[employee._id];
      saveImageMap(map);

      await load();
    } catch (e) {
      setError(errorMessage(e));
    }
  }

  return (
    <section className="panel employee-list-panel">
      <div className="panel-head">
        <div>
          <h2>Edit Employee</h2>
          <p>Search and select an employee to edit or delete.</p>
        </div>

        <button className="secondary" onClick={onBack}>
          <ArrowLeft /> Back
        </button>
      </div>

      {error && (
        <div className="inner-alert">
          <Alert type="error" text={error} close={() => setError("")} />
        </div>
      )}

      <EmployeeFilters
        search={search}
        setSearch={v => { setSearch(v); setPage(1); }}
        department={department}
        setDepartment={v => { setDepartment(v); setPage(1); }}
        status={status}
        setStatus={v => { setStatus(v); setPage(1); }}
        sort={sort}
        setSort={v => { setSort(v); setPage(1); }}
        clear={() => {
          setSearch("");
          setDepartment("");
          setStatus("");
          setSort("-joiningDate");
          setPage(1);
        }}
      />

      <EmployeeTable
        employees={employees}
        loading={loading}
        showActions
        onEmployeeClick={employee => setSelected(employee)}
        onEdit={employee => setSelected(employee)}
        onDelete={remove}
      />

      <Pagination
        pagination={pagination}
        page={page}
        setPage={setPage}
        loading={loading}
      />
    </section>
  );
}

/* =========================
   EMPLOYEE DETAILS
========================= */

function EmployeeDetails({ employee, onBack, onEdit }) {
  const [current, setCurrent] = useState(employee || null);
  const [error, setError] = useState("");

  useEffect(() => {
    setCurrent(employee || null);
  }, [employee]);

  if (!current) {
    return (
      <section className="panel detail-empty">
        <Users />
        <h2>Employee not found</h2>
        <button className="secondary" onClick={onBack}>
          <ArrowLeft /> Back
        </button>
      </section>
    );
  }

  const image = current.profileImage || getImageMap()[current._id] || "";

  async function deleteEmployee() {
    if (!current._id) {
      setError("Invalid employee ID.");
      return;
    }

    if (!window.confirm(
      `Delete ${current.name}? This action cannot be undone.`
    )) return;

    try {
      await employeeApi.remove(current._id);

      const map = getImageMap();
      delete map[current._id];
      saveImageMap(map);

      onBack();
    } catch (e) {
      setError(errorMessage(e));
    }
  }

  return (
    <section className="employee-detail-page">
      <button className="back-button detail-back" onClick={onBack}>
        <ArrowLeft /> Back
      </button>

      {error && <Alert type="error" text={error} close={() => setError("")} />}

      <div className="panel detail-card">
        <div className="detail-hero">
          <Avatar image={image} fallback={initials(current.name)} size={118} />

          <div className="detail-heading">
            <span className="detail-label">EMPLOYEE PROFILE</span>
            <h2>{current.name}</h2>
            <p>{current.role} · {current.department}</p>
            <span className={`status ${current.status.toLowerCase()}`}>
              <i /> {current.status}
            </span>
          </div>

          <div className="detail-actions">
            <button className="primary" onClick={() => onEdit(current)}>
              <Edit3 /> Edit Employee
            </button>
            <button className="danger-button" onClick={deleteEmployee}>
              <Trash2 /> Delete Employee
            </button>
          </div>
        </div>

        <div className="detail-grid">
          <DetailItem icon={<Mail />} label="Email" value={current.email} />
          <DetailItem icon={<Phone />} label="Phone" value={current.phone || "-"} />
          <DetailItem icon={<BriefcaseBusiness />} label="Role" value={current.role} />
          <DetailItem icon={<Building2 />} label="Department" value={current.department} />
          <DetailItem icon={<BadgeDollarSign />} label="Salary" value={currency(current.salary)} />
          <DetailItem icon={<CalendarDays />} label="Joining Date" value={dateText(current.joiningDate)} />
        </div>
      </div>
    </section>
  );
}

function DetailItem({ icon, label, value }) {
  return (
    <div className="detail-item">
      <div className="detail-item-icon">{icon}</div>
      <div>
        <small>{label}</small>
        <b>{value}</b>
      </div>
    </div>
  );
}

/* =========================
   FILTERS / TABLE
========================= */

function EmployeeFilters({
  search, setSearch, department, setDepartment,
  status, setStatus, sort, setSort, clear
}) {
  return (
    <div className="filters">
      <div className="search">
        <Search />
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Search name, email or role..."
        />
      </div>

      <div className="select-icon">
        <Filter />
        <select
          value={department}
          onChange={e => setDepartment(e.target.value)}
        >
          <option value="">All Departments</option>
          {departments.map(d => <option key={d}>{d}</option>)}
        </select>
      </div>

      <select value={status} onChange={e => setStatus(e.target.value)}>
        <option value="">All Statuses</option>
        <option>Active</option>
        <option>Inactive</option>
      </select>

      <select value={sort} onChange={e => setSort(e.target.value)}>
        <option value="-joiningDate">Newest First</option>
        <option value="joiningDate">Oldest First</option>
        <option value="name">Name A–Z</option>
        <option value="-name">Name Z–A</option>
        <option value="-salary">Salary High–Low</option>
        <option value="salary">Salary Low–High</option>
      </select>

      <button className="clear" onClick={clear}>Clear</button>
    </div>
  );
}

function EmployeeTable({
  employees, loading, showActions = false,
  onEmployeeClick, onEdit, onDelete
}) {
  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr>
            <th>Employee</th>
            <th>Role</th>
            <th>Department</th>
            <th>Contact</th>
            <th>Salary</th>
            <th>Joined</th>
            <th>Status</th>
            {showActions && <th>Actions</th>}
          </tr>
        </thead>

        <tbody>
          {loading ? (
            <tr>
              <td colSpan={showActions ? 8 : 7}>
                <div className="empty">
                  <span className="loading-ring" />
                  <b>Loading employees...</b>
                </div>
              </td>
            </tr>
          ) : employees.length === 0 ? (
            <tr>
              <td colSpan={showActions ? 8 : 7}>
                <div className="empty">
                  <Users />
                  <b>No employees found</b>
                  <span>No employee records match this view.</span>
                </div>
              </td>
            </tr>
          ) : (
            employees.map(e => (
              <EmployeeRow
                key={e._id}
                employee={e}
                clickable={Boolean(onEmployeeClick)}
                onEmployeeClick={() => onEmployeeClick?.(e)}
                edit={() => onEdit?.(e)}
                remove={() => onDelete?.(e)}
                showActions={showActions}
              />
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}

function EmployeeRow({
  employee, clickable, onEmployeeClick, edit, remove, showActions
}) {
  const image = employee.profileImage || getImageMap()[employee._id] || "";

  return (
    <tr
      className={clickable ? "employee-row-clickable" : ""}
      onClick={clickable ? onEmployeeClick : undefined}
      tabIndex={clickable ? 0 : undefined}
      onKeyDown={clickable ? e => {
        if (e.key === "Enter" || e.key === " ") onEmployeeClick();
      } : undefined}
    >
      <td>
        <div className="employee">
          <Avatar image={image} fallback={initials(employee.name)} />
          <div>
            <b>{employee.name}</b>
            <span>{employee.email}</span>
          </div>
        </div>
      </td>

      <td>
        <span className="role">
          <BriefcaseBusiness /> {employee.role}
        </span>
      </td>

      <td>{employee.department}</td>

      <td>
        <div className="contact">
          <span><Phone /> {employee.phone || "-"}</span>
          <span><Mail /> {employee.email}</span>
        </div>
      </td>

      <td><b>{currency(employee.salary)}</b></td>
      <td>{dateText(employee.joiningDate)}</td>

      <td>
        <span className={`status ${employee.status.toLowerCase()}`}>
          <i /> {employee.status}
        </span>
      </td>

      {showActions && (
        <td onClick={e => e.stopPropagation()}>
          <div className="actions">
            <button onClick={edit} title="Edit Employee">
              <Edit3 />
            </button>
            <button onClick={remove} title="Delete Employee">
              <Trash2 />
            </button>
          </div>
        </td>
      )}
    </tr>
  );
}

function Avatar({ image, fallback, size = 42 }) {
  return image
    ? <img className="profile-avatar" style={{ width: size, height: size }} src={image} alt="" />
    : <div className="profile-avatar initials-avatar" style={{ width: size, height: size }}>{fallback}</div>;
}

function Pagination({ pagination, page, setPage, loading }) {
  if (pagination.totalPages <= 1) return null;

  return (
    <div className="pagination">
      <div className="pages">
        <button
          disabled={page <= 1 || loading}
          onClick={() => setPage(p => p - 1)}
        >
          <ArrowLeft />
        </button>

        {Array.from(
          { length: pagination.totalPages },
          (_, i) => i + 1
        ).map(n => (
          <button
            key={n}
            className={n === page ? "current" : ""}
            disabled={loading}
            onClick={() => setPage(n)}
          >
            {n}
          </button>
        ))}

        <button
          disabled={page >= pagination.totalPages || loading}
          onClick={() => setPage(p => p + 1)}
        >
          <ChevronRight />
        </button>
      </div>
    </div>
  );
}

/* =========================
   ADD / EDIT EMPLOYEE FORM
========================= */

function EmployeeForm({ employee, onSaved }) {
  const [form, setForm] = useState(() => makeEmployeeForm(employee));
  const [errors, setErrors] = useState({});
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");
  const [image, setImage] = useState(employee?.profileImage || "");

  useEffect(() => {
    setForm(makeEmployeeForm(employee));
    setImage(employee?.profileImage || "");
    setErrors({});
    setMessage("");
  }, [employee]);

  function update(field, value) {
    setForm(f => ({ ...f, [field]: value }));
    setErrors(e => ({ ...e, [field]: "" }));
  }

  function chooseImage(e) {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      setMessage("Please select an image file.");
      return;
    }

    if (file.size > 2 * 1024 * 1024) {
      setMessage("Profile image must be 2 MB or smaller.");
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      setImage(reader.result);
      setMessage("");
    };
    reader.readAsDataURL(file);
  }

  async function submit(e) {
    e.preventDefault();

    const err = {};

    if (!form.name.trim()) err.name = "Name is required.";
    if (!form.email.trim() ||
        !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      err.email = "Valid email is required.";
    }
    if (!form.role.trim()) err.role = "Role is required.";
    if (!form.department) err.department = "Department is required.";
    if (
      form.salary === "" ||
      Number(form.salary) < 0 ||
      Number.isNaN(Number(form.salary))
    ) {
      err.salary = "Valid salary is required.";
    }
    if (!form.joiningDate) err.joiningDate = "Joining date is required.";

    setErrors(err);

    if (Object.keys(err).length) return;

    setSaving(true);
    setMessage("");

    try {
      let response;
      const payload = {
        ...form,
        salary: Number(form.salary)
      };

      if (employee?._id) {
        response = await employeeApi.update(employee._id, payload);
      } else {
        response = await employeeApi.create(payload);
      }

      const id =
        employee?._id ||
        response.data?.data?._id ||
        response.data?._id;

      if (id && image) {
        const map = getImageMap();
        map[id] = image;
        saveImageMap(map);
      }

      setMessage(
        employee
          ? "Employee updated successfully."
          : "Employee added successfully."
      );

      setTimeout(() => onSaved(), 700);
    } catch (e) {
      setMessage(errorMessage(e));
    } finally {
      setSaving(false);
    }
  }

  return (
    <form className="manage-form" onSubmit={submit}>
      <div className="employee-photo-field">
        <div className="large-profile-preview">
          <Avatar
            image={image}
            fallback={initials(form.name)}
            size={96}
          />
        </div>

        <div>
          <b>Profile Image</b>
          <span>JPG, PNG or WEBP · Max 2 MB</span>

          <label className="upload-button">
            <Camera />
            {image ? "Change Image" : "Upload Image"}
            <input
              type="file"
              accept="image/png,image/jpeg,image/webp"
              onChange={chooseImage}
            />
          </label>
        </div>
      </div>

      {message && <div className="form-message">{message}</div>}

      <div className="form-grid">
        <Field label="Full Name" required error={errors.name}>
          <input
            value={form.name}
            onChange={e => update("name", e.target.value)}
            placeholder="John Perera"
          />
        </Field>

        <Field label="Email" required error={errors.email}>
          <input
            type="email"
            value={form.email}
            onChange={e => update("email", e.target.value)}
            placeholder="john@example.com"
          />
        </Field>

        <Field label="Phone">
          <input
            value={form.phone}
            onChange={e => update("phone", e.target.value)}
            placeholder="0771234567"
          />
        </Field>

        <Field label="Role" required error={errors.role}>
          <input
            list="employee-roles"
            value={form.role}
            onChange={e => update("role", e.target.value)}
            placeholder="Software Engineer"
          />
          <datalist id="employee-roles">
            {roles.map(r => <option key={r} value={r} />)}
          </datalist>
        </Field>

        <Field label="Department" required error={errors.department}>
          <select
            value={form.department}
            onChange={e => update("department", e.target.value)}
          >
            <option value="">Select department</option>
            {departments.map(d => (
              <option key={d}>{d}</option>
            ))}
          </select>
        </Field>

        <Field label="Salary (LKR)" required error={errors.salary}>
          <input
            type="number"
            min="0"
            value={form.salary}
            onChange={e => update("salary", e.target.value)}
            placeholder="150000"
          />
        </Field>

        <Field label="Joining Date" required error={errors.joiningDate}>
          <input
            type="date"
            value={form.joiningDate}
            onChange={e => update("joiningDate", e.target.value)}
          />
        </Field>

        <Field label="Status">
          <select
            value={form.status}
            onChange={e => update("status", e.target.value)}
          >
            <option>Active</option>
            <option>Inactive</option>
          </select>
        </Field>
      </div>

      <div className="form-actions">
        <button className="primary" disabled={saving}>
          <Save />
          {saving
            ? "Saving..."
            : employee
              ? "Save Changes"
              : "Create Employee"}
        </button>
      </div>
    </form>
  );
}

function makeEmployeeForm(employee) {
  if (!employee) return { ...initialEmployee };

  return {
    name: employee.name || "",
    email: employee.email || "",
    phone: employee.phone || "",
    role: employee.role || "",
    department: employee.department || "",
    salary: employee.salary ?? "",
    joiningDate: employee.joiningDate
      ? new Date(employee.joiningDate).toISOString().slice(0, 10)
      : initialEmployee.joiningDate,
    status: employee.status || "Active"
  };
}

function Field({ label, required, error, children }) {
  return (
    <label className="field">
      <span>{label}{required && <b> *</b>}</span>
      {children}
      {error && <small>{error}</small>}
    </label>
  );
}

/* =========================
   DEPARTMENTS
========================= */

function Departments({ onNavigate }) {
  const [selected, setSelected] = useState("");
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function choose(name) {
    setSelected(name);
    setLoading(true);
    setError("");

    try {
      const res = await employeeApi.getAll({
        page: 1,
        limit: 1000,
        department: name,
        sort: "name"
      });

      const map = getImageMap();

      setEmployees(
        (res.data?.data || []).map(e => ({
          ...e,
          profileImage: map[e._id] || ""
        }))
      );
    } catch (e) {
      setError(errorMessage(e));
      setEmployees([]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="departments-page">
      {error && <Alert type="error" text={error} close={() => setError("")} />}

      <section className="department-grid">
        {departments.map(name => (
          <button
            key={name}
            className={`department-card ${selected === name ? "selected" : ""}`}
            onClick={() => choose(name)}
          >
            <span className="department-icon"><Building2 /></span>
            <span className="department-card-text">
              <b>{name}</b>
              <small>View employees</small>
            </span>
            <ChevronRight />
          </button>
        ))}
      </section>

      {selected ? (
        <section className="panel department-results">
          <div className="panel-head">
            <div>
              <h2>{selected} Employees</h2>
              <p>Click an employee to view complete details.</p>
            </div>
          </div>

          <EmployeeTable
            employees={employees}
            loading={loading}
            showActions={false}
            onEmployeeClick={employee => onNavigate("details", {
              employee,
              backView: "departments"
            })}
          />
        </section>
      ) : (
        <div className="department-placeholder">
          <Building2 size={40} />
          <h2>Select a department</h2>
          <p>Click a department above to see its employees.</p>
        </div>
      )}
    </div>
  );
}

/* =========================
   ADMIN PROFILE
========================= */

function AdminProfile({ admin, onSave }) {
  const [form, setForm] = useState({
    ...admin,
    newPassword: "",
    confirmPassword: ""
  });
  const [message, setMessage] = useState("");
  const [image, setImage] = useState(admin.photo || "");
  const [changingPassword, setChangingPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  function update(k, v) {
    setForm(f => ({ ...f, [k]: v }));
    setMessage("");
  }

  function startPasswordChange() {
    setChangingPassword(true);
    setMessage("");
    setTimeout(() => document.getElementById("new-admin-password")?.focus(), 0);
  }

  function cancelPasswordChange() {
    setChangingPassword(false);
    setShowNewPassword(false);
    setShowConfirmPassword(false);
    setForm(f => ({ ...f, newPassword: "", confirmPassword: "" }));
    setMessage("");
  }

  function imageChange(e) {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      setMessage("Please select an image.");
      return;
    }

    if (file.size > 2 * 1024 * 1024) {
      setMessage("Profile image must be 2 MB or smaller.");
      return;
    }

    const r = new FileReader();
    r.onload = () => setImage(r.result);
    r.readAsDataURL(file);
  }

  function save(e) {
    e.preventDefault();

    if (!form.name.trim() || !form.username.trim() || !form.email.trim()) {
      return setMessage("Name, username and email are required.");
    }

    if (changingPassword) {
      if (form.newPassword.length < 6) {
        return setMessage("New password must contain at least 6 characters.");
      }

      if (form.newPassword !== form.confirmPassword) {
        return setMessage("New passwords do not match.");
      }
    }

    onSave({
      name: form.name.trim(),
      username: form.username.trim(),
      email: form.email.trim(),
      phone: form.phone.trim(),
      password: changingPassword ? form.newPassword : admin.password,
      photo: image
    });

    setForm(f => ({ ...f, newPassword: "", confirmPassword: "" }));
    setChangingPassword(false);
    setShowNewPassword(false);
    setShowConfirmPassword(false);
  }

  return (
    <section className="profile-page">
      <div className="panel profile-card">
        <div className="panel-head">
          <div>
            <h2>Admin Profile</h2>
            <p>Manage your account, profile photo and login details.</p>
          </div>

          <span className="secure-badge">
            <ShieldCheck /> Admin Account
          </span>
        </div>

        <form className="profile-form" onSubmit={save}>
          <div className="admin-photo">
            <Avatar
              image={image}
              fallback={initials(form.name)}
              size={112}
            />

            <div>
              <b>Profile Photo</b>
              <span>Use a clear JPG, PNG or WEBP image.</span>

              <label className="upload-button">
                <Camera /> Change Photo
                <input
                  type="file"
                  accept="image/png,image/jpeg,image/webp"
                  onChange={imageChange}
                />
              </label>
            </div>
          </div>

          {message && <div className="form-message">{message}</div>}

          <div className="form-grid">
            <Field label="Full Name" required>
              <input
                value={form.name}
                onChange={e => update("name", e.target.value)}
              />
            </Field>

            <Field label="Username" required>
              <input
                value={form.username}
                onChange={e => update("username", e.target.value)}
              />
            </Field>

            <Field label="Email" required>
              <input
                type="email"
                value={form.email}
                onChange={e => update("email", e.target.value)}
              />
            </Field>

            <Field label="Phone">
              <input
                value={form.phone}
                onChange={e => update("phone", e.target.value)}
              />
            </Field>
          </div>

          <div className="password-section">
            {!changingPassword ? (
              <div className="password-change-row">
                <div>
                  <b>Account Password</b>
                  <span>Change your login password securely.</span>
                </div>
                <button
                  type="button"
                  className="secondary"
                  onClick={startPasswordChange}
                >
                  <LockKeyhole /> Change Password
                </button>
              </div>
            ) : (
              <div className="password-change-panel">
                <div className="password-change-heading">
                  <div>
                    <b>Change Password</b>
                    <span>Enter a new password and confirm it below.</span>
                  </div>
                  <button
                    type="button"
                    className="password-cancel"
                    onClick={cancelPasswordChange}
                  >
                    Cancel
                  </button>
                </div>

                <div className="form-grid password-grid">
                  <Field label="New Password" required>
                    <div className="password-field">
                      <LockKeyhole />
                      <input
                        id="new-admin-password"
                        type={showNewPassword ? "text" : "password"}
                        value={form.newPassword}
                        onChange={e => update("newPassword", e.target.value)}
                        placeholder="Enter new password"
                        autoComplete="new-password"
                      />
                      <button
                        type="button"
                        className="password-toggle profile-password-toggle"
                        onClick={() => setShowNewPassword(v => !v)}
                        aria-label={showNewPassword ? "Hide new password" : "Show new password"}
                      >
                        {showNewPassword ? <EyeOff /> : <Eye />}
                      </button>
                    </div>
                  </Field>

                  <Field label="Confirm New Password" required>
                    <div className="password-field">
                      <KeyRound />
                      <input
                        type={showConfirmPassword ? "text" : "password"}
                        value={form.confirmPassword}
                        onChange={e => update("confirmPassword", e.target.value)}
                        placeholder="Repeat new password"
                        autoComplete="new-password"
                      />
                      <button
                        type="button"
                        className="password-toggle profile-password-toggle"
                        onClick={() => setShowConfirmPassword(v => !v)}
                        aria-label={showConfirmPassword ? "Hide confirm password" : "Show confirm password"}
                      >
                        {showConfirmPassword ? <EyeOff /> : <Eye />}
                      </button>
                    </div>
                  </Field>
                </div>
              </div>
            )}
          </div>

          <div className="form-actions">
            <button className="primary">
              <Save /> Save Profile
            </button>
          </div>
        </form>
      </div>
    </section>
  );
}

function BackButton({ onClick, label = "Back" }) {
  return (
    <button className="back-button" onClick={onClick}>
      <ArrowLeft /> {label}
    </button>
  );
}

function Alert({ type, text, close }) {
  return (
    <div className={`alert ${type}`}>
      <span>{text}</span>
      <button onClick={close}><X /></button>
    </div>
  );
}
