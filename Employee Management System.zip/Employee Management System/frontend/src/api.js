import axios from "axios";

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || "http://localhost:5000/api",
  headers: { "Content-Type": "application/json" },
});

export const employeeApi = {
  getAll: (params = {}) => api.get("/employees", { params }),
  getById: (id) => {
    if (!id) throw new Error("Invalid employee ID");
    return api.get(`/employees/${id}`);
  },
  create: (data) => api.post("/employees", data),
  update: (id, data) => {
    if (!id) throw new Error("Invalid employee ID");
    return api.put(`/employees/${id}`, data);
  },
  remove: (id) => {
    if (!id) throw new Error("Invalid employee ID");
    return api.delete(`/employees/${id}`);
  },
};

export default api;
